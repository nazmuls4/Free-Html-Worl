



var config = {

    countdown: {
        year: 2018,
        month: 6,
        day: 16,
        hours: 24,
        minutes: 12,
        seconds: 21
    },

    subscription_form_tooltips: {

        /* On successful subscription */
        success: "You have been subscribed!",

        /* On some unknown error */
        default_error: "Error! Please, contact administration.",

        /* When email field is empty */
        empty_email: "Please, enter your email.",

        /* When email is invalid (for example, there is no @ character in it) */
        invalid_email: "Email is invalid. Please, enter valid email address.",

        /* When submitted email is already on the list */
        already_subscribed: "You are already subscribed."
    }
}
